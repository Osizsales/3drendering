/**
 * Created with IntelliJ IDEA.
 * User: moo
 * Date: 14-10-21
 * Time: 下午5:05
 * TW声音控制器 组件
 */
(function(){
    window.TWFlyOutMediaClass = JTCore.extend({
        init:function(options,name,prefix,pathType){
            this.pathPrefix = prefix;
            this.imgPathArr = options;
            this.name = name;
            this.padding = 36;
            this.closeImgPath = "./resources/flyoutmedia/close.png";
            this.leftImgPath = "./resources/flyoutmedia/left.png";
            this.rightImgPath = "./resources/flyoutmedia/right.png";
            this.pathType =pathType;
            this.index = 0;
            this.imgWidth = 0;
            this.imgHeight = 0;
            this.imgDown = false;
            this.imgMove = false;
            this.downX = 0;
            this.moveX = 0;
            this.count = this.imgPathArr.length;
            this.container = TWMainWindowObj.target ? TWMainWindowObj.target : document.body;
            this.setTargetSize();
            //加载Dom结构
            this.loadDom();
            this.addResizeEvent();
        },
        setTargetSize:function(){
            this.width = TWMainWindowObj.stageWidth;
            this.height = TWMainWindowObj.stageHeight;
        },
        loadDom:function(){
            var self = this;
            var showIndex = ++TWIndex;
            if(this.pathType == 1){
                this.showImgDom =JTHelp.cDom("div").setProperties({
                    name:this.name,
                    id:this.name
                }).setStyles({
                        position:"absolute",
                        zIndex: showIndex,
                        overflow:"hidden"
                    }).inject(this.container);
                EventUtil.addEvent(this.showImgDom,TWEvent.eventClick,function(e){self.closeFlyOutMedial();});
                this.loadImage();
                return;
            }

            this.target = JTHelp.cDom("div").setProperties({
                name:this.name,
                id:this.name
            }).setStyles({
                    position:"absolute",
                    zIndex:showIndex,
                    backgroundColor:"rgba(255,255,255,0.6)",
                    width: "0px",
                    height: "0px",
                    left:this.width/2 + "px",
                    top:this.height/2 + "px"
                }).inject(this.container);
            if(TWBrowser.pc == "pc"){
                this.closeDom = JTHelp.cDom("div").setStyles({
                    position:"absolute",
                    width:"36px",
                    height:"36px",
                    backgroundImage:"url("+this.closeImgPath+")",
                    backgroundRepeat:"no-repeat",
                    backgroundPosition: "center",
                    cursor:"pointer",
                    right:"0px",
                    top:"0px"
                }).inject(this.target);
                EventUtil.addEvent(this.closeDom,TWEvent.eventClick,function(e){
                    self.closeFlyOutMedial();
                });
            }
            this.leftDom = JTHelp.cDom("div").setStyles({
                position:"absolute",
                width:"36px",
                height:"36px",
                left:"0px",
                top:"50%"
            }).inject(this.target);
            this.leftImgDom = JTHelp.cDom("div").setStyles({
                position:"absolute",
                width:"36px",
                height:"36px",
                backgroundImage:"url("+this.leftImgPath+")",
                backgroundRepeat:"no-repeat",
                backgroundPosition: "center",
                cursor:"pointer",
                top:"-50%"
            }).inject(this.leftDom);
            EventUtil.addEvent(this.leftImgDom,TWEvent.eventClick,function(e){
                self.leftImage();
            });

            this.rightDom = JTHelp.cDom("div").setStyles({
                position:"absolute",
                width:"36px",
                height:"36px",
                right:"0px",
                top:"50%"
            }).inject(this.target);
            this.rightImgDom = JTHelp.cDom("div").setStyles({
                position:"absolute",
                width:"36px",
                height:"36px",
                backgroundImage:"url("+this.rightImgPath+")",
                backgroundRepeat:"no-repeat",
                backgroundPosition: "center",
                cursor:"pointer",
                top:"-50%"
            }).inject(this.rightDom);
            EventUtil.addEvent(this.rightDom,TWEvent.eventClick,function(e){
                self.rightImage();
            });

            this.showTextDom = JTHelp.cDom("div").setStyles({
                position:"absolute",
                width:"100%",
                height:"36px",
                lineHeight:"36px",
                bottom:"0px",
                textAlign:"center"
            }).inject(this.target);
            this.setShowText();

            this.showImgDom =JTHelp.cDom("div").setStyles({
                position:"absolute",
                overflow:"hidden",
                left: "36px",
                top:"36px"
            }).inject(this.target);

            EventUtil.addEvent(this.showImgDom,TWEvent.eventDown,function(e){self.imgDownEvent(e);});
            EventUtil.addEvent(this.showImgDom,TWEvent.eventMove,function(e){self.imgMoveEvent(e);});
            EventUtil.addEvent(this.showImgDom,TWEvent.eventUp,function(e){self.imgUpEvent(e);});
            EventUtil.addEvent(this.showImgDom,TWEvent.eventOut,function(e){self.imgOutEvent(e);});
            this.loadImage();

        },
        loadImage:function(){
            this.imgDom && this.imgDom.destroy() && (this.imgDom = null);
            !this.imgDom && (this.imgDom = JTHelp.cDom("img"));
            this.imgDom.setStyles({
                position:"absolute",
                pointerEvents:"none",
                width:"100%",
                height:"100%",
                left:"0px",
                top:"0px",
                opacity:0
            });
            var self = this;
            this.imgDom.src = this.pathPrefix + "/" + this.imgPathArr[this.index];
            this.imgDom.onload = function(){
                //删除loading提示
                TWSceneObj&&TWSceneObj.delPlayTip();
                //加载与上一张一样的图片
                if(self.imgWidth == this.width && self.imgHeight == this.height){
                    self.target.style[TWBrowser.prefix + "Transition"] = "";
                    var c = self.getImgBestSize();
                    self.showImage(c);
                }else{
                    self.imgWidth = this.width;
                    self.imgHeight = this.height;
                    self.setImgResize(this.width,this.height);
                }


            };
        },
        imgDownEvent:function(e){
            e = EventUtil.getEvent(e);
            e = e.changedTouches && e.changedTouches[0] || e;
            EventUtil.stopDefault(e);EventUtil.stopPropagation(e);
            this.imgDown = true;
            this.downX = e.pageX;
            this.imgDom.style[TWBrowser.prefix + "Transition"] = "";
        },
        imgMoveEvent:function(e){
            e = EventUtil.getEvent(e);
            e = e.changedTouches && e.changedTouches[0] || e;
            EventUtil.stopDefault(e);EventUtil.stopPropagation(e);
            if(this.imgDown){
                this.imgMove = true;
                this.moveX =  e.pageX - this.downX;
                this.imgDom.style.left = this.moveX + "px";
            }
        },
        imgUpEvent:function(e){
            e = EventUtil.getEvent(e);
            e = e.changedTouches && e.changedTouches[0] || e;
            EventUtil.stopDefault(e);EventUtil.stopPropagation(e);
            var self = this;
            if(this.imgMove){
                if(Math.abs(this.moveX) > 100){
                    (this.moveX  > 0) && (this.leftImage());
                    (this.moveX  < 0) && (this.rightImage());
                }else{
                    this.imgDom.css3Animate({left:0},0.5,function(){
                        self.imgDom.style[TWBrowser.prefix + "Transition"] = "";
                    });
                }

            }else{
                if(TWBrowser.pc == "pc"){
                    var lt = this.showImgDom.getBoundingClientRect();
                    var rectW = lt.width;
                    var clickX = e.pageX - lt.left;
                    if(clickX < rectW * 0.5){
                        this.leftImage();
                    }
                    if(clickX > rectW * 0.5){
                        this.rightImage();
                    }
                }else{
                    this.closeFlyOutMedial();
                }
            }
            this.downX = 0;
            this.imgMove = false;
            this.imgDown = false;

        },
        imgOutEvent:function(e){
            e = EventUtil.getEvent(e);
            e = e.changedTouches && e.changedTouches[0] || e;
            var self = this;
            EventUtil.stopDefault(e);EventUtil.stopPropagation(e);
            this.imgDom.css3Animate({left:0},0.5,function(){
                self.imgDom.style[TWBrowser.prefix + "Transition"] = "";
            });
            this.downX = 0;
            this.imgMove = false;
            this.imgDown = false;
        },
        getShowText : function (){
            return  (this.index +1) +"/"  + (this.count);
        },
        setShowText:function(){
            this.showTextDom && (this.showTextDom.innerHTML = this.getShowText());
        },
        closeFlyOutMedial:function(){
            this.showImgDom && this.showImgDom.destroy();
            this.target && this.target.destroy();
            //这个累加到window上面的size事件 在对象消除的时候一定要删除掉事件
            EventUtil.removeEvent(window,TWEvent.resize,this.resizeTarget);
            TWFlyOutMediaObj = null;
        },
        leftImage:function(){
            ((this.index - 1) < 0) ? this.index = (this.count - 1) : this.index  = this.index -1;
            this.loadImage();
            this.setShowText();
        },
        rightImage:function(){
            ((this.index + 1) >= this.count) ? this.index = 0 : this.index  = this.index + 1;
            this.loadImage();
            this.setShowText();
        },
        getImgBestSize:function(){
            if(this.pathType == 1){this.padding = 0;}
            var s ={};
            if(((this.imgWidth + this.padding*2) > this.width) || ((this.imgHeight + this.padding*2) > this.height)){
                s=JTHelp.getBestFitSize(this.imgWidth,this.imgHeight,this.width - this.padding*2,this.height - this.padding*2);
            }else{
                s = {width:this.imgWidth,height:this.imgHeight};
            }
            var c = JTHelp.getCenterSize(s.width, s.height,this.width,this.height);
            return c;
        },
        setImgResize:function(){
            var c = this.getImgBestSize();
            if(this.pathType == 1){
                this.showImage(c);
            }else{
                var self = this;
                this.target.style[TWBrowser.prefix + "Transition"] = "";
                this.target.css3Animate({
                    width: (c.width + self.padding*2) +"px",
                    height:(c.height + self.padding * 2) + "px",
                    left:(c.left -self.padding) +"px",
                    top:(c.top -self.padding)+"px"
                },0.2,function(){
                    self.target.style[TWBrowser.prefix + "Transition"] = "";
                    self.showImage(c);
                });
            }

        },
        showImage:function(c){
            if(this.pathType == 1){
                this.showImgDom.setStyles({
                    left : (this.width - c.width)/2 + "px",
                    top : (this.height - c.height)/2 + "px",
                    width:c.width+"px",
                    height:c.height + "px",
                    display:"block"
                });
            }else{
                this.showImgDom.setStyles({
                    width:c.width+"px",
                    height:c.height + "px",
                    display:"block"
                });
            }

            this.imgDom.inject(this.showImgDom);
            var self = this;
            this.imgDom.css3Animate({opacity:1},0.2,function(){
                self.imgDom.style[TWBrowser.prefix + "Transition"] = "";
            });
        },
        resizeTarget:function(){
            TWFlyOutMediaObj.setTargetSize();
            TWFlyOutMediaObj.setImgResize();
        },
        addResizeEvent:function(){
            //这个累加到window上面的size事件 在对象消除的时候一定要删除掉事件
            EventUtil.addEvent(window,TWEvent.resize,this.resizeTarget);
        }

    });
})();